import sqlite3

conn = sqlite3.connect("candidates.db")
conn.row_factory = sqlite3.Row   # 🔥 THIS LINE
cursor = conn.cursor()

cursor.execute("""
        SELECT * FROM candidates
        ORDER BY id DESC
        LIMIT 1
    """)
all_candidates = cursor.fetchone()
dict_candidates = dict(all_candidates)
print(dict_candidates)

conn.close()
