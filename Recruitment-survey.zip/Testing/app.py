import csv
import sqlite3
import send_mail
import candidateDB
from flask import Flask, render_template, request, send_file, redirect, url_for


app = Flask(__name__)

@app.route("/")
def home():
    return render_template("welcome.html", username="Abhishek")

@app.route("/form")
def goToForm():
    return render_template("form.html")


@app.route("/submit-survey", methods=["POST"])
def submit_survey():
    full_name = request.form.get("full_name")
    email = request.form.get("email")
    mobile = request.form.get("mobile")
    gender = request.form.get("gender")
    designation = request.form.get("designation")
    total_experience = request.form.get("total_experience")
    relevant_experience = request.form.get("relevant_experience")
    primary_skills = request.form.get("primary_skills")
    secondary_skills = request.form.get("secondary_skills")
    current_ctc = request.form.get("current_ctc")
    expected_ctc = request.form.get("expected_ctc")
    preferred_location = request.form.get("preferred_location")
    current_location = request.form.get("current_location")
    notice_period = request.form.get("notice_period")

    # Important for checkbox
    employment_type = ", ".join(request.form.getlist("employment_type"))

    profile_link = request.form.get("profile_link")
    additional_info = request.form.get("additional_info")

    conn = sqlite3.connect("candidates.db")
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO candidates (
        full_name, email, mobile, gender, designation,
        total_experience, relevant_experience,
        primary_skills, secondary_skills,
        current_ctc, expected_ctc,
        preferred_location, current_location,
        notice_period, employment_type,
        profile_link, additional_info
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        full_name, email, mobile, gender, designation,
        total_experience, relevant_experience,
        primary_skills, secondary_skills,
        current_ctc, expected_ctc,
        preferred_location, current_location,
        notice_period, employment_type,
        profile_link, additional_info
    ))

    conn.commit()
    conn.close()

    return redirect(url_for("view_candidates"))



# @app.route("/download-candidates")
# def download_candidates():
#     return send_file(
#         "candidates.csv",
#         as_attachment=True,
#         download_name="IT_Candidates.csv"
#     )


@app.route("/candidates")
def view_candidates():
    conn = sqlite3.connect("candidates.db")
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("""
        SELECT * FROM candidates
        ORDER BY id DESC
        LIMIT 1
    """)

    candidate = cursor.fetchone()   # only one row
    
    if candidate:  # convert row to dict safely
        candidate_dict = dict(candidate)
    else:
        candidate_dict = {}  # empty dict if no data

    conn.close()
    
    return render_template("candidates.html", candidate=candidate_dict)



# @app.route("/send-mail")
# def sendMail():
#     with open("templates/candidates.html", "r", encoding="utf-8") as f:
#         html_content = f.read()

#     send_mail.send_email(html_content)
#     return "Mail has been sent successfully"


app.run(port=15000)


