import smtplib
from email.message import EmailMessage


def send_email(html_content):

    # Email details
    sender_email = "abhishekpandey3479@gmail.com"
    receiver_email = "rvshsvsvc@gmail.com"
    app_password = "qpsi bybg cohn axdo"   # your 16-character app password

    # Create email
    msg = EmailMessage()
    msg["Subject"] = "Test Email from Python"
    msg["From"] = sender_email
    msg["To"] = receiver_email

    # Set both plain text and HTML (Best practice)
    msg.set_content("Please find the attached survey form")

    msg.add_alternative(html_content, subtype="html")

    # Send email
    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls()          # Secure the connection
        server.login(sender_email, app_password)
        server.send_message(msg)

    print("✅ Email sent successfully!")
