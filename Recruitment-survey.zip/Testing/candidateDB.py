import sqlite3

conn = sqlite3.connect("candidates.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT,
    email TEXT,
    mobile TEXT,
    gender TEXT,
    designation TEXT,
    total_experience TEXT,
    relevant_experience TEXT,
    primary_skills TEXT,
    secondary_skills TEXT,
    current_ctc TEXT,
    expected_ctc TEXT,
    preferred_location TEXT,
    current_location TEXT,
    notice_period TEXT,
    employment_type TEXT,
    profile_link TEXT,
    additional_info TEXT
)
""")

conn.commit()
conn.close()
